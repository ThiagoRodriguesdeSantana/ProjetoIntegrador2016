package entidade;

public enum StatusPerfil {

        Privado,
	Publico,
	
        
        

}

