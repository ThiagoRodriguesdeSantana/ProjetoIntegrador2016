package entidade;

public enum StatusRelacionamento {

	Casado,
	Solteiro,
	Divorciado,
	Viuvo,
	Nenhum,
}
