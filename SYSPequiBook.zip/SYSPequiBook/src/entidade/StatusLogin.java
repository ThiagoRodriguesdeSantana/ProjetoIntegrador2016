package entidade;

public enum StatusLogin {

	Logado,
	Deslogado,
	Indisponivel,
	
}
